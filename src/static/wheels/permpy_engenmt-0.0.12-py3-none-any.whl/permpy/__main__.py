from permpy.permset import PermSet
from permpy.permutation import Permutation
from permpy.pegpermutation import PegPermutation
from permpy.permclass import PermClass
from permpy.avclass import AvClass
from permpy.pegpermset import PegPermSet
from permpy.geometricgridclass import GeometricGridClass

# from permpy.InsertionEncoding import *
import permpy.RestrictedContainer

import doctest

doctest.testmod()
